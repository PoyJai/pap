const SpaceApp = {
    data: [
        {
            id: 1, brand: "Terrestrial", name: "ดาวพุธ (Mercury)", price: "ดาวที่ใกล้ดวงอาทิตย์ที่สุด",
            img: "https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?auto=format&fit=crop&q=80&w=800",
            specs: ["โคจร: 88 วัน", "ไม่มีดาวบริวาร", "ไร้ชั้นบรรยากาศ"],
            desc: "ดาวเคราะห์ที่มีขนาดเล็กที่สุดในระบบสุริยะ พื้นผิวเต็มไปด้วยหลุมอุกกาบาต มีความผันผวนของอุณหภูมิสูงมาก ตั้งแต่ร้อนจัดในเวลากลางวันจนถึงเย็นจัดในเวลากลางคืน"
        },
        {
            id: 2, brand: "Terrestrial", name: "ดาวศุกร์ (Venus)", price: "ฝาแฝดโลกที่ร้อนที่สุด",
            img: "https://images.unsplash.com/photo-1614313913007-2b4ae8ce32d6?auto=format&fit=crop&q=80&w=800",
            specs: ["โคจร: 225 วัน", "หมุนย้อนกลับ", "แก๊สเรือนกระจก"],
            desc: "ดาวเคราะห์ที่สว่างที่สุดบนท้องฟ้า มีชั้นบรรยากาศหนาทึบที่กักเก็บความร้อน จนมีอุณหภูมิพื้นผิวสูงถึง 465 องศาเซลเซียส ซึ่งร้อนพอที่จะละลายตะกั่วได้"
        },
        {
            id: 3, brand: "Habitable", name: "โลก (Earth)", price: "บ้านสีน้ำเงินของเรา",
            img: "https://images.unsplash.com/photo-1614730321146-b6fa6a46bcb4?auto=format&fit=crop&q=80&w=800",
            specs: ["โคจร: 365 วัน", "มีดวงจันทร์ 1 ดวง", "มีสิ่งมีชีวิต"],
            desc: "โลกเป็นดาวเคราะห์เพียงดวงเดียวในขณะนี้ที่พบว่ามีสิ่งมีชีวิตอาศัยอยู่ มีน้ำในสถานะของเหลวปกคลุมพื้นที่กว่า 70% และมีชั้นบรรยากาศที่ช่วยป้องกันรังสีอันตราย"
        },
        {
            id: 4, brand: "Terrestrial", name: "ดาวอังคาร (Mars)", price: "ดาวเคราะห์สีแดง",
            img: "https://images.unsplash.com/photo-1545156521-77bd85671d30?auto=format&fit=crop&q=80&w=800",
            specs: ["โคจร: 687 วัน", "มีดวงจันทร์ 2 ดวง", "ภูเขาไฟยักษ์"],
            desc: "เป็นดาวที่มีความคล้ายคลึงกับโลกมากที่สุด มีฤดูกาลและน้ำแข็งที่ขั้วดาว มีภูเขาไฟโอลิมปัสซึ่งเป็นภูเขาไฟที่สูงที่สุดในระบบสุริยะ"
        },
        {
            id: 5, brand: "Gas Giant", name: "ดาวพฤหัสบดี (Jupiter)", price: "ยักษ์ใหญ่แห่งระบบสุริยะ",
            img: "https://images.unsplash.com/photo-1630839437035-dac17da580d0?auto=format&fit=crop&q=80&w=800",
            specs: ["โคจร: 12 ปี", "ดวงจันทร์ 95 ดวง", "พายุหมุนยักษ์"],
            desc: "ดาวเคราะห์ที่มีมวลมากที่สุด มีลักษณะเป็นก๊าซทั้งหมด ไม่มีพื้นผิวแข็ง มีจุดแดงใหญ่ซึ่งเป็นพายุหมุนขนาดมหึมาที่อยู่ยงคงกระพันมานานกว่า 300 ปี"
        }
    ],

    init() {
        this.renderList();
    },

    renderList() {
        const container = document.getElementById('planet-list-container');
        if(!container) return;
        container.innerHTML = this.data.map(item => `
            <div class="card" onclick="SpaceApp.openDetail(${item.id})">
                <div class="card-img-container">
                    <img src="${item.img}" alt="${item.name}" class="product-img">
                </div>
                <div class="card-body">
                    <span class="brand-tag">${item.brand}</span>
                    <h3 style="margin: 0.5rem 0;">${item.name}</h3>
                    <p style="color: var(--text-dim); font-size: 0.8rem;">${item.price}</p>
                    <button class="btn-view">อ่านความรู้</button>
                </div>
            </div>
        `).join('');
    },

    showPage(pageId) {
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        document.getElementById(pageId).classList.add('active');
        window.scrollTo(0,0);
    },

    openDetail(id) {
        const item = this.data.find(p => p.id === id);
        const view = document.getElementById('detail-view');
        view.innerHTML = `
            <button class="btn-view" style="width: auto; padding: 0.5rem 1rem; margin-bottom: 2rem;" onclick="SpaceApp.showPage('home')">← กลับหน้าหลัก</button>
            <div class="detail-container">
                <div class="detail-img-box">
                    <img src="${item.img}" alt="${item.name}" style="width:100%;">
                </div>
                <div class="detail-info">
                    <span class="brand-tag">${item.brand}</span>
                    <h2 style="font-size: 2.5rem; margin-top: 10px;">${item.name}</h2>
                    <p style="color: var(--accent-blue); margin-bottom: 1.5rem;">${item.price}</p>
                    <p style="line-height: 1.8; color: #cbd5e1;">${item.desc}</p>
                    <div class="detail-specs-grid">
                        <div class="spec-item"><strong>คาบการโคจร</strong><p>${item.specs[0]}</p></div>
                        <div class="spec-item"><strong>บริวาร</strong><p>${item.specs[1]}</p></div>
                        <div class="spec-item"><strong>จุดเด่น</strong><p>${item.specs[2]}</p></div>
                    </div>
                </div>
            </div>
        `;
        this.showPage('detail');
    }
};

window.onload = () => SpaceApp.init();